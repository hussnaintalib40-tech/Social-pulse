import React, { useState } from 'react';
import { LayoutDashboard, Mail, ArrowRight, Loader2, Lock } from 'lucide-react';
import { View } from '../types';

interface AuthPageProps {
  onNavigate: (view: View) => void;
  onLogin: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onNavigate, onLogin }) => {
  const [isLoading, setIsLoading] = useState<'google' | 'email' | null>(null);

  const handleLogin = (type: 'google' | 'email') => {
    setIsLoading(type);
    // Simulate auth delay
    setTimeout(() => {
      setIsLoading(null);
      onLogin();
      onNavigate('dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center py-12 px-4 animate-in fade-in duration-500">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-50 p-8 text-center border-b border-gray-100">
          <div className="bg-primary-500 text-white p-2 rounded-xl inline-flex mb-4 shadow-lg shadow-primary-200">
            <LayoutDashboard className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Welcome Back</h1>
          <p className="text-slate-500">Sign in to access your dashboard</p>
        </div>

        {/* Content */}
        <div className="p-8 space-y-4">
          
          <button 
            onClick={() => handleLogin('google')}
            disabled={isLoading !== null}
            className="w-full flex items-center justify-center gap-3 bg-white border border-gray-200 hover:bg-gray-50 text-slate-700 font-bold py-3 rounded-xl transition-all shadow-sm hover:shadow active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isLoading === 'google' ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.17c-.22-.66-.35-1.36-.35-2.17s.13-1.51.35-2.17V7.01H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.99l3.66-2.82z" />
                <path fill="#EA4335" d="M12 4.86c1.61 0 3.06.56 4.21 1.64l3.16-3.16C17.45 1.49 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.01l3.66 2.82c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
            )}
            Continue with Google
          </button>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-slate-400 font-bold">Or continue with</span>
            </div>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleLogin('email'); }} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-500 mb-1 ml-1">Email Address</label>
              <input 
                type="email" 
                placeholder="you@example.com"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-all bg-slate-50 focus:bg-white"
              />
            </div>
            <button 
              type="submit"
              disabled={isLoading !== null}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl transition-all shadow-lg active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading === 'email' ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>Sign In with Email <ArrowRight className="w-4 h-4" /></>
              )}
            </button>
          </form>

        </div>

        {/* Footer */}
        <div className="px-8 py-4 bg-slate-50 border-t border-gray-100 text-center">
          <p className="text-xs text-slate-400">
            By continuing, you agree to our <button onClick={() => onNavigate('terms')} className="text-primary-600 hover:underline">Terms</button> and <button onClick={() => onNavigate('privacy')} className="text-primary-600 hover:underline">Privacy Policy</button>.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;